/** MCP JSON-RPC stdio server with a small CAP tool surface. */
import readline from 'node:readline';
import { searchCapabilities } from './search.js';
import { addCapability } from './registry.js';
import { useCapability } from './use.js';
import { inspectLocal } from './inspector.js';
import { planInjection } from './inject.js';
import { exposedCapTools } from './mcp-tools.js';
import { packageVersion } from './paths.js';

async function callTool(name, args, options) {
  if (name === 'cap.search') return searchCapabilities(args.query, {...options, limit: args.limit});
  if (name === 'cap.add') return addCapability(args.capability_id, args.provider_id, {...options, server: args.server});
  if (name === 'cap.use') return useCapability(args.capability_id, args.input, options);
  if (name === 'cap.inject') return planInjection(args.query, {...options, limit: args.limit});
  if (name === 'cap.inspect') return inspectLocal(options);
  throw new Error(`Unknown tool: ${name}`);
}

export async function handleMcpMessage(message, options = {}) {
  const base = {jsonrpc: '2.0', id: message.id};
  try {
    if (message.method === 'initialize') return {...base, result: {protocolVersion: message.params?.protocolVersion ?? '2025-06-18', capabilities: {tools: {}}, serverInfo: {name: 'cap', version: packageVersion()}}};
    if (message.method === 'notifications/initialized') return null;
    if (message.method === 'ping') return {...base, result: {}};
    if (message.method === 'tools/list') return {...base, result: {tools: exposedCapTools(options)}};
    if (message.method === 'tools/call') {
      if (!exposedCapTools(options).some((tool) => tool.name === message.params?.name)) throw new Error(`Tool is not exposed: ${message.params?.name}`);
      const result = await callTool(message.params?.name, message.params?.arguments ?? {}, options);
      return {...base, result: {content: [{type: 'text', text: JSON.stringify(result, null, 2)}], structuredContent: result}};
    }
    return {...base, error: {code: -32601, message: `Method not found: ${message.method}`}};
  } catch (error) {
    return {...base, error: {code: -32000, message: error.message}};
  }
}

export async function startMcpServer(options = {}) {
  const input = readline.createInterface({input: process.stdin, crlfDelay: Infinity});
  for await (const line of input) {
    if (!line.trim()) continue;
    let response;
    try { response = await handleMcpMessage(JSON.parse(line), options); }
    catch (error) { response = {jsonrpc: '2.0', id: null, error: {code: -32700, message: error.message}}; }
    if (response) process.stdout.write(`${JSON.stringify(response)}\n`);
  }
}
